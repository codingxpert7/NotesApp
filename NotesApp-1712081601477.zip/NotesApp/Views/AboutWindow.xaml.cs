namespace Notes.Views;

public partial class AboutWindow : ContentPage
{
	public AboutWindow()
	{
		InitializeComponent();
	}

    private async void KnowMore_Clicked(object sender, EventArgs e)
    {
        if (BindingContext is Models.AboutObject  aboutObj)
        {
            await Launcher.Default.OpenAsync(aboutObj.InfoUrl);
        }
    }
}