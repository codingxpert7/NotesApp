namespace Notes.Views;

public partial class ShowNotes : ContentPage
{
    public ShowNotes()
    {
        InitializeComponent();
        BindingContext = new Models.NotesList();
    }

    protected override void OnAppearing()
    {
        ((Models.NotesList)BindingContext).DisplayNotes();
    }

    private async void onAddClicked(object sender, EventArgs e)
    {
        await Shell.Current.GoToAsync(nameof(NoteWindow));
    }

    private async void onSelectionChanged(object sender, SelectionChangedEventArgs e)
    {
        if (e.CurrentSelection.Count != 0)
        {
            var noteObj = (Models.NoteObject)e.CurrentSelection[0];
            await Shell.Current.GoToAsync($"{nameof(NoteWindow)}?{nameof(NoteWindow.ItemId)}={noteObj.FilePath}");
            notesList.SelectedItem = null;
        }
    }
}