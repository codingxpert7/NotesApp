﻿using System.Collections.ObjectModel;

namespace Notes.Models;

internal class NotesList
{
    public ObservableCollection<NoteObject> allNotes { get; set; } = new ObservableCollection<NoteObject>();

    public NotesList() =>
        DisplayNotes();

    public void DisplayNotes()
    {
        this.allNotes.Clear();
        string storagePath = FileSystem.AppDataDirectory;
        IEnumerable<NoteObject> allNotes = Directory
                                    .EnumerateFiles(storagePath, "*.notes.txt")
                                    .Select(filePath => new Note()
                                    {
                                        FilePath = filePath,
                                        Content = File.ReadAllText(filePath),
                                        TimeStamp = File.GetLastWriteTime(filePath)
                                    })
                                    .OrderBy(note => note.TimeStamp);
        foreach (NoteObject noteObj in allNotes)
            this.allNotes.Add(noteObj);
    }
}