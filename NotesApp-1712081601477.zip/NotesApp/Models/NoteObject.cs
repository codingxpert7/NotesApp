﻿namespace Notes.Models;

internal class NoteObject
{
    public string FilePath { get; set; }
    public string Content { get; set; }
    public DateTime TimeStamp { get; set; }
}