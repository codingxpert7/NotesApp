﻿namespace Notes.Models;

internal class AboutObject
{
    public string Title => AppInfo.Name;
    public string InfoUrl => "https://aka.ms/maui";
    public string Message => "This is a basic notes app written in .NET MAUI framework.Allows the user to make notes and view it for later use.";
    public string Version => AppInfo.VersionString;
}