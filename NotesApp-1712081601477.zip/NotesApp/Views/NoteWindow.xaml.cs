namespace Notes.Views;

[QueryProperty(nameof(ItemId), nameof(ItemId))]
public partial class NoteWindow : ContentPage
{
    public string ItemId
    {
        set { ShowNote(value); }
    }

    public NoteWindow()
    {
        InitializeComponent();
        string storagePath = FileSystem.AppDataDirectory;
        string generatedName = $"{Path.GetRandomFileName()}.notes.txt";
        ShowNote(Path.Combine(storagePath, generatedName));
    }

    private void ShowNote(string filePath)
    {
        Models.NoteObject noteObject = new Models.NoteObject();
        noteObject.Filename = filePath;

        if (File.Exists(filePath))
        {
            noteObject.TimeStamp = File.GetCreationTime(filePath);
            noteObject.Content = File.ReadAllText(filePath);
        }

        BindingContext = noteObject;
    }

    private async void SaveButton_Action(object sender, EventArgs e)
    {
        if (BindingContext is Models.NoteObject noteObj)
            File.WriteAllText(noteObj.FilePath, TextEditor.Text);
        await Shell.Current.GoToAsync("..");
    }

    private async void DeleteButton_Action(object sender, EventArgs e)
    {
        if (BindingContext is Models.NoteObject noteObj)
        {
            // Delete the file.
            if (File.Exists(noteObj.FilePath))
                File.Delete(noteObj.FilePath);
        }

        await Shell.Current.GoToAsync("..");
    }
}